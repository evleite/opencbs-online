Ember.js
========

Shim repository for [Ember Application Framework](http://emberjs.com/).

This package provides the core of the ember.js framework.

Package Managers
----------------

* [Bower](http://bower.io): `ember`
* [Composer](http://packagist.org/packages/components/ember): `components/ember`
